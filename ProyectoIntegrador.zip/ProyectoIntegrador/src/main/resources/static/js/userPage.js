function buscarProductos() {
    const buscarProducto = document.getElementById('buscarProducto').value;

    // Lógica para enviar la solicitud de búsqueda al servidor (puedes usar Fetch API)
    // ...

    // Actualizar el listado de productos después de la búsqueda
    // ...

    // Limpiar el campo de búsqueda
    document.getElementById('buscarProducto').value = '';
}

document.addEventListener('DOMContentLoaded', function() {
    // Lógica para obtener y mostrar el listado de productos
    // ...


});
