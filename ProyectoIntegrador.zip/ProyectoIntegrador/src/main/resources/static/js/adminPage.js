document.addEventListener('DOMContentLoaded', function() {
    const registrarProductoForm = document.getElementById('registrarProductoForm');
    const listadoProductos = document.getElementById('listadoProductos');

    // Lógica para registrar un nuevo producto
    registrarProductoForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const nombre = document.getElementById('nombre').value;
        const precio = document.getElementById('precio').value;

        // Lógica para enviar la solicitud de registro al servidor (puedes usar Fetch API)
        // ...

        // Actualizar el listado de productos después de registrar
        // ...

        // Limpiar el formulario
        registrarProductoForm.reset();
    });


});
