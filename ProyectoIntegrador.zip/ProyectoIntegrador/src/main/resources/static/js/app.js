document.addEventListener('DOMContentLoaded', function () {
    const productForm = document.getElementById('productForm');
    const productList = document.getElementById('productList');
    const clientProductList = document.getElementById('clientProductList');
    const searchInput = document.getElementById('search');
    const adminSection = document.querySelector('#adminSection');
    const clientSection = document.querySelector('#clientSection');

    // Obtener información del usuario
    fetch('/productos/info-usuario')
        .then(response => response.text())
        .then(rol => {
            // Mostrar u ocultar secciones basadas en el rol
            if (rol === 'ADMIN') {
                adminSection.classList.add('visible');
                clientSection.classList.remove('visible');
            } else if (rol === 'CLIENTE') {
                adminSection.classList.remove('visible');
                clientSection.classList.add('visible');
            } else {
                // Lógica para manejar el caso de usuario anónimo
                adminSection.classList.remove('visible');
                clientSection.classList.remove('visible');
            }
        });

    productForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const productName = document.getElementById('productName').value;
        const productPrice = document.getElementById('productPrice').value;
        const productImage = document.getElementById('productImage').value;

        // Agregar producto a la lista de productos
        const productItem = document.createElement('li');
        productItem.innerHTML = `<img src="${productImage}" alt="${productName}"><h4>${productName}</h4><p>Precio: $${productPrice}</p>`;
        productList.appendChild(productItem);

        // También agregar producto a la lista de productos para el cliente
        const clientProductItem = document.createElement('li');
        clientProductItem.innerHTML = `<img src="${productImage}" alt="${productName}"><h4>${productName}</h4><p>Precio: $${productPrice}</p>`;
        clientProductList.appendChild(clientProductItem);

        // Limpiar campos del formulario
        productForm.reset();
    });

    // Filtrar productos para el cliente según la búsqueda
    searchInput.addEventListener('input', function () {
        const searchTerm = searchInput.value.toLowerCase();
        const clientProducts = clientProductList.querySelectorAll('li');

        clientProducts.forEach(function (product) {
            const productText = product.textContent.toLowerCase();
            if (productText.includes(searchTerm)) {
                product.style.display = 'block';
            } else {
                product.style.display = 'none';
            }
        });
    });
});