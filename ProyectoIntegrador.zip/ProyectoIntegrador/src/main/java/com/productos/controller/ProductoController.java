package com.productos.controller;

import com.productos.model.DTO.ProductoDTO;
import com.productos.model.Producto;
import com.productos.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @PostMapping("/registrar")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Void> registrarProducto(@RequestBody ProductoDTO productoDTO) {
        productoService.registrarProducto(productoDTO);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @DeleteMapping("/eliminar/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> eliminarProducto(@PathVariable Long id) {
        productoService.eliminarProducto(id);
        return new ResponseEntity<>("Producto eliminado exitosamente", HttpStatus.OK);
    }

    @GetMapping("/buscar")
    @PreAuthorize("hasRole('ROLE_CLIENTE')")
    public ResponseEntity<List<Producto>> buscarPorPalabraClave(@RequestParam String palabraClave) {
        List<Producto> productos = productoService.listarProductosPorPalabraClave(palabraClave);
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }

    @GetMapping("/listado")
    @PreAuthorize("hasRole('ROLE_CLIENTE')")
    public ResponseEntity<List<Producto>> obtenerListadoCompletoCliente() {
        List<Producto> productos = productoService.obtenerTodos();
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }

    @GetMapping("/listadoCompleto")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<List<Producto>> obtenerListadoCompleto() {
        List<Producto> productos = productoService.obtenerTodos();
        return new ResponseEntity<List<Producto>>(productos, HttpStatus.OK);
    }


}
