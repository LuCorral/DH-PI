// Esta Clase controller es la parte que maneja las interacciones del usuario
//Gestiona solicitudes del usuario y actualiza la vista
package com.productos.controller;

import com.productos.model.DTO.ProductoDTO;
import com.productos.model.Producto;
import com.productos.service.ProductoService;
import com.productos.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController // controller + responsebody, renderiza directamente la respuesta del metodo a la respuesta HTTP
@RequestMapping("/productos") //ruta base de todas las operaciones en este controlador
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @Autowired
    private UserService userService;

    @GetMapping("/info-usuario")
    public ResponseEntity<String> obtenerInfoUsuario(Authentication authentication) {
        if (authentication != null) {
            boolean esAdmin = authentication.getAuthorities()
                    .stream()
                    .anyMatch(authority -> "ROLE_ADMIN".equals(authority.getAuthority()));

            return ResponseEntity.ok(esAdmin ? "ADMIN" : "CLIENTE");
        } else {
            return ResponseEntity.ok("ANONYMOUS");
        }
    }

    // Endpoint para que el admin obtenga el listado completo de productos
    @Secured("ROLE_ADMIN")
    @GetMapping("/listadoCompleto")
    public ResponseEntity<List<Producto>> obtenerListadoCompleto(@AuthenticationPrincipal UserDetails userDetails) {
        if (userService.isUserAdmin(userDetails.getUsername())) {
            // Lógica para obtener el listado completo de productos por el admin
            List<Producto> productos = productoService.obtenerTodos();
            return new ResponseEntity<>(productos, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
    }


    @Secured("ROLE_ADMIN")
    @PostMapping("/registrar")
    public ResponseEntity<Void> registrarProducto(@RequestBody ProductoDTO productoDTO,
                                                  @AuthenticationPrincipal UserDetails userDetails) {
        if (userService.isUserAdmin(userDetails.getUsername())) {
            // Lógica para registrar el producto por el admin
            productoService.registrarProducto(productoDTO);
            return new ResponseEntity<>(HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
    }

    @Secured("ROLE_ADMIN")
    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> eliminarProducto(@PathVariable Long id,
                                                   @AuthenticationPrincipal UserDetails userDetails) {
        if (userService.isUserAdmin(userDetails.getUsername())) {
            // Lógica para eliminar el producto por el admin
            productoService.eliminarProducto(id);
            return new ResponseEntity<>("Producto eliminado exitosamente", HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
    }



    // Endpoint para que el cliente busque productos por palabra clave
    @Secured("ROLE_CLIENTE")
    @GetMapping("/buscar")
    public ResponseEntity<List<Producto>> buscarPorPalabraClave(@RequestParam String palabraClave) {
        // Lógica para buscar productos por palabra clave para el cliente
        List<Producto> productos = productoService.listarProductosPorPalabraClave(palabraClave);
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }

    // Endpoint para que el cliente obtenga el listado completo de productos
    @Secured("ROLE_CLIENTE")
    @GetMapping("/listado")
    public ResponseEntity<List<Producto>> obtenerListadoCompletoCliente() {
        // Lógica para obtener el listado completo de productos para el cliente
        List<Producto> productos = productoService.obtenerTodos();
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }

}
