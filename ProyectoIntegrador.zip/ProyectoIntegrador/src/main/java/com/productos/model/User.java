package com.productos.model;

import jakarta.persistence.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
@Table(name = "users")
public class User implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "password")
    private String password;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "rol_id"))
    private Set<Role> Rol;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Rol.stream()
                .map(role -> new SimpleGrantedAuthority(role.getNombre()))
                .collect(Collectors.toSet());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<Role> getRol() {
        return Rol;
    }

    public void setRol(Set<Role> rol) {
        Rol = rol;
    }



    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return nombre;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true; // Puedes personalizar esto según tu lógica de negocio
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // Puedes personalizar esto según tu lógica de negocio
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // Puedes personalizar esto según tu lógica de negocio
    }

    @Override
    public boolean isEnabled() {
        return true; // Puedes personalizar esto según tu lógica de negocio
    }

}
