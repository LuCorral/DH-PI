package com.productos.model.DTO;

import lombok.Data;

@Data
public class ProductoDTO {

    private String nombre;
    private double precio;
    private String imageUrl;

    public String getImageUrl() {
        return imageUrl;
    }
}
