package com.productos.model.DTO;

import java.util.Set;

public class UserDTO {
    private String nombre;
    private String password;
    private Set<RoleDTO> rol;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<RoleDTO> getRol() {
        return rol;
    }

    public void setRol(Set<RoleDTO> rol) {
        this.rol = rol;
    }
}
