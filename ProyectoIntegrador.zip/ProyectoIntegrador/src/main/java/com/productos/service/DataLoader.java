/*package com.productos.service;

import com.productos.Repository.UserRepository;
import com.productos.model.User;
import com.productos.model.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements ApplicationRunner { // para poder cargar a la base de datos cuando se ejecuta mi app
    private UserRepository userRepository;
    @Autowired
    public DataLoader(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    @Override
    public void run(ApplicationArguments args) throws Exception{
            BCryptPasswordEncoder passwordEncoder =new BCryptPasswordEncoder();
            String password = passwordEncoder.encode("password");
            String password2= passwordEncoder.encode("password2");
            // Aca cuando mi aplicacion levante va a generar estos dos usuarios uno como User y otro Admin
        userRepository.save(new User("lucorral", "lucorral8@gmail.com", password, Role.ROLE_ADMIN));
        userRepository.save(new User("pepito123","pepe123@gmail.com", password2,Role.ROLE_USER ));

    }



}
*/