package com.productos.service;
import com.productos.Repository.UserRepository;
import com.productos.model.User;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByNombre(username);
        if (user == null) {
            throw new UsernameNotFoundException("Usuario no encontrado: " + username);
        }
        return user;
    }

    public boolean isUserInRole(String username, String roleName) {
        User user = userRepository.findByNombre(username);
        return user != null && user.getRol().stream().anyMatch(role -> roleName.equals(role.getNombre()));
    }

    public boolean isUserAdmin(String username) {
        return isUserInRole(username, "ROLE_ADMIN");
    }

    public boolean isUserCliente(String username) {
        return isUserInRole(username, "ROLE_CLIENTE");
    }

    // Otros métodos del servicio...
}